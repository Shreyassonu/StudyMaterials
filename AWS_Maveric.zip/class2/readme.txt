# IAM: Users and Groups

IAM = identity and access management, Global Service
Root account created by default, shouldn't ne used or shared
Users are people within your organization and can be grouped
Groups only contain users, not other groups
Users doont have to belong to a group, and user can belong to multiple groups


# IAM: Permission
- users or groups can be assigned JSON documents called policies
- these policies define the permissions of the users
- in AWS you apply the least privilege priciple: dont give more permission than a user needs

# 1: Hands On Users and Group



# IAM Policies
- Consists of
  Version - policy language, always include "2012-10-17"
  Id - an identifier for the policy (optional)
  Statement - one or more individual statement (required)

- statements consist of
   Sid - an identifier for the statement (optional)
   Effect - wheather the statment allows or denies access (Allow / Deny)
   Principal - account/user/role to which this policy applied to
   Action - list of actions this policy allows or denies
   Resource  - list of resource to which the action applied to
   Condition - conditions for when this policy is in effect (option)


{
	"Version": "2012-10-17",
	"Id": "",
	"Statement": [{
		"Sid": "1",
		"Effect": "Allow",
		"Principal": {
			"AWS": [""]
		},
		"Action": [
			"S3:GetObject",
			"S3:PutObject"
		],
		"Resource": ["arn:aws:s3:::mybuckey"]
	}]
}


#2 : Handon Policy


# IAM  - Password Policy
- Strong Passwords = higher security for your account
- In AWS you can setup a password policy
 - set a minimum password length
 - require specific charcter type
    incliding upper letter
     lowercase letter
     numbers
     non alphanumeric character
- allow all IAM users to change their own password
- require users to chnage their password after some time (password exporation)
- prevent password re-use



# MFA - multi factor Authentication
- users have access to your account and can possible chnage configuration or delete resources in your aws account
- you want to protect your root account and IAM users

MFA = password you know + security devive you own


user password + MFA = successful login


Main Benefits of MFA
- if a password is stolen or hacked the account is not compromised


# Device Options
1. Google Authenticate - phone only
2. Authy - multi-device
3. universal 2nd factor security key


#3: Hands on Password Policy and MFA


# AWS Access Key
- to access AWS, we have 3 options
  - AWS Management Console (protected by password + MFA)
  - AWS command line interface (CLI) (protected by access key)
  - AWS Software Developer Kit (SDK) (protected by access key)

- access key are generated tgrough aws console
- users manage their own access key
- access key are secret just like a password - dont share with anyone

Access key Id - username
Secret Access Key - password



Access key : AKIATD3QFBB22RIYO5GZ
Secret access key  :   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



# AWS CLI - 
- a tool that enables you to interact with AWS services using commands in you command line shell
- direct access to the public APIs of aws service
- you can develop scripts to manage your resources
- alternative to using AWS Mangement console

https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html


# AWS SDK
- AWS software development kit
- language specific APIs
- enable you to access and manage aws services programmatically
- embedded within your app
- supports 
   SDK - JS, PHP, Jaav etc
   Mobile SDK - android, ios
   IoT Device SDK



> aws configure
AWS Access Key ID [****************FQS5]: 
AWS Secret Access Key [****************jBmv]: 
Default region name [us-east-1]:
Default output format [json]:

> aws iam list-users


# CloudShell

> aws iam list-users
> ls
> echo "test" > demo.txt
> ls
> pwd


# IAM Roles for services
- some aws services will need to perform actions on your behalf
- to do so we will assign permission to aws services with IAM roles
- common roles
   - EC2 instance roles
   - lambda function roles
   - roles for cloudFormation


#5 Hands on Role
Step 1: create a new role with IAMReadOnly Policy attach
Step 2: create new EC2 Linux instance
Step 3: connect with EC2  using ssh




# IAM Best Practices
- Dont use the root account except for AWS account setup
- one physical user = one aws user
- assign users to group and assign permision to group
- create a strong password policy
- use and enforce the use of MFA
- create and use roles for giving permission to aws services
- use access key for programmatic access (CLI/SDK)
- never share IAM users and acces key





