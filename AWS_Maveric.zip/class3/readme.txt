# S3 - simple storage 

- amazon s3 is one of the main building block of aws
- it advertised as infinity scaling storage

- many websites use amazon s3 as a backbone
- many aws servives use amazon s3 as an intergration as well


# Amazon S3 use cases
- backup and storage
- disaster recovery
- archite
- hybrid cloud storage
- application hosting
- media hosting
- data late & bog data analytics
- software delivery
- static website


# Amazon S3 - buckets

- amazon s3 allows people to store objects (file) in bucket (directory)
- buckets must have a globally unique name (across all region all accounts)
- buckets are defined at the region level
- S3 looks like a global service but bucket are created in a region
- naming convetion
 - no uppercase, no underscore
 - 3-63 character long
 - not an IP
 - must start with lowercase letter or number
 - must not start with the prefix xn--
 - must not end with the suffix -s3alias



# Amazon S3 - object
- object (files) have a key
- the key is in full path
  - s3://my-bucket/my_file.txt
  - s3://my-bucket/my_folder/another_folder/my_file.txt

- the key is composed of prefix + object name
  - s3://my_bucket/my_folder/my_file.txt

- object value are the content of the body
 - max - object size is 5TB
 - if uploaded more then 5GB must be use multi-part upload



# Amazon S3 - security
- user based
 - IAM POlices - which API call should be allowed for a specific user from IAM

- resource-based
 - bucket policies - bucket wide rules from s3 console
 - object access control list - finer grain 
 - bucket access control list - less common 

note: an IAM principal can access an s3 object if
	- the user IAM permnission allow it or the resource policy allow it
 	- and there no explict deny

encryption : encrupt objects in amazon s3 using encryption keys



# S# bucket poliies

- json based policy


{
    "Version": "2012-10-17",
    "Id": "Policy1696325527219",
    "Statement": [
        {
            "Sid": "Stmt1696325516072",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:*",
            "Resource": "arn:aws:s3:::my-bucket-2307/*"
        }
    ]
}


# amazon S3 - static website hosting

S3 can host static website and have them accessible on the internet

htt://bucket-name.s3-website-aws-region.amazonawscom




# Amazon S3 - Versioning

- you can version your files in amzon s3
- it is enabled at the bucket level
- same key overwrite will change the version : 1,2,3
- it is best practice to version your buckets
  - protect against unintended deletes
  - easy roll back to previons version

note: any file that is not versioned prior to enabling versioning will have version "nul"



# Question: I want to deploy my spring boot app on aws

EC2 - IaaS
Elastic BeanStack - PaaS



Solution 1: create and ec2 instamce and deploy the spring boot app

1. create a sample spring boot app and create a jar file
2. create an linux EC2
3. ssh into linux instance
4. sudo -i
5. wget https://download.oracle.com/java/17/latest/jdk-17_linux-x64_bin.rpm
6. rpm -ivh jdk-17_linux-x64_bin.rpm
7. java --version
8. wget https://my-bucket-2307.s3.ap-south-1.amazonaws.com/spring-boot-sample-app-0.0.1-SNAPSHOT.jar
9. ls
10. java -jar <jar file name>
11. modify the security group to allow the relavent port number
12. test the app on browser with public IP address






