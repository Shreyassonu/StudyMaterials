# AWS: RDS + Aurora + Elasic Cache

# AWS RDS
- RDS stands for Relational Database Services
- it a managed DB service for DB use SQL as a query language
- it allows you to create databasees in the cloud that are managed by AWS
 - Postgress
 - MySQL
 - MariaDB
 - Oracle
 - MS SQL Server
 - Aurora (AWS Proprietary Database)


# Advatnage over using RDS versus deploying DB on EC2
- RDS is a managed servicves
  -  automated provisioning, OS patching
  - continous backups and restore to specific timestamp
  - monitoring dashboard
  - multi az setup for Disater recovery
  - maintenance windows for upgrades
  - scaling capability (vertical and horizontal)
  - storage backed by EBS 
- but you can't SSH into your instance

helps you incerase storage on your RDS DB instance dynamically
- when RDS detect you are running out of free databvase storage ot scakles automatically
- avoid manually scalling your database storage
- you have to set maximin storage storage threshiold (max limit for db storage)

- support all RDS database engine


connection string

mysql -u root -p ""


> mysql -h database-1.cqzsyhmipmhw.ap-south-1.rds.amazonaws.com -u admin -p

mysql://localhost:3306/mydb
mysql://database-1.cqzsyhmipmhw.ap-south-1.rds.amazonaws.com/



# Amazon Aurora
- it is proprietory technology from aws - not open sourced
- postgress and mysql are both support as aurora db 
- aurora is aws cloud optimized a d claims 5x performance improvement over mysql on RDS over 3x performance of postgress
- aurora storage automatically grox in increment of 10GB upto 128 TB
- aurora can have upto 15 replicas and the repliocation process is faater then mysql
- aurora cost more then  RDS (20% more) - but is more efficient



# ElastiCache
- the same way RDS is to get managed relational database
- elastic chache is to get managed redis or memcache
- caches are in-memory database with really high performance, low latency
- helps reduce load off of database for read intensive workload
- helps make your app stateless




# Redis vs Memcached
- multi az with auto failover
- read replicas to scale read and have high availability
- data durability
- back up and restore features
- support set and sorted set


- muti-node for partitioning of data
- no high availability
- non persistemce
- no backup and restore
- multi threaded architecture


# ASG - Auto Scaling Group
 - scale out (add EC2 instances) to match an increased load
 - scale in (remove EC2 instances) to match a decrese load
 -  ensure we have minimum and max number of EC2 instance running
 - automatically register new instabce to a load balancer
 - re create an ec2 instance in case a previous one is terminated


ASG are free (you have to pay for the underlying EC2 instance)


A launch Template 
 - AMI + instance Type
 - EC2 User Data
 - EBS colume
 - Security Group
 - SSH Key pait
 - IAM roles
 - network + subnet info
 - laod balancer info

- min size / max size / initial capacity
- scaling policies





#!/bin/bash
# Use this for your user data (script from top tom bottom)
# install httpd (Linux 2 version)
yum update -y
yum install -y httpd
systemctl start httpd
systemctl enable httpd
echo "<h1>Hello World from $(hostname -f)</h1>" > /var/www/html/index.html



